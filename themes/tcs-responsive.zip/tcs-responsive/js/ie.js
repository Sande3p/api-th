$(document).ready(function() {	
	$('input[placeholder]').inputHints();
})

