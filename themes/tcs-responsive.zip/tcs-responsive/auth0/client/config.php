<?php
$auth0_cfg = array(
    'domain'        => 'pemula.auth0.com',
    'client_id'     => 'nR3bpXP9keGjk2JDC3DQqurpmTPkmq0K',
    'client_secret' => '0qVE_o82PxxI4RhQIS98beoRbJdm7Ooox3KyUhMEzAsuzWg3rL7yOMCw52X80tPe',
    'redirect_uri'  => 'http://pemula.dev/reviewer/tc-cs/callback/'
);