<?php get_header(); ?>
<div id="main">
	<div class="container notFound">
	<br/><br/>
<h2 align="center" class="st-404">
404<br/>
Not Found
</h2>
<br/><br/>
</div>
</div>

<?php get_footer(); ?>
